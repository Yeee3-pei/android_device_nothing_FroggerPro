savedcmd_usr/include/drm/drm.h := sh /mnt/data2/lineageos/kernel/nothing/sm7750/scripts/headers_install.sh /mnt/data2/lineageos/kernel/nothing/sm7750/include/uapi/drm/drm.h usr/include/drm/drm.h
